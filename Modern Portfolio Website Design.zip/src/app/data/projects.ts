export interface Project {
  id: string;
  title: string;
  subtitle: string;
  category: "ui" | "graphic" | "3d";
  categoryLabel: string;
  image: string;
  year: string;
  role: string;
  duration: string;
  tools: string[];
  overview: string;
  problem: string;
  process: string[];
  solution: string;
  result: string;
}

export const projects: Project[] = [
  {
    id: "finflow",
    title: "FinFlow",
    subtitle: "Mobile Banking App Redesign",
    category: "ui",
    categoryLabel: "UI Design",
    image: "https://images.unsplash.com/photo-1476885084911-210727f73472?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBhcHAlMjBVSSUyMGRlc2lnbiUyMG1vY2t1cCUyMGRhcmt8ZW58MXx8fHwxNzc0NDQ4NTkzfDA&ixlib=rb-4.1.0&q=80&w=1080",
    year: "2025",
    role: "Lead Visual Designer",
    duration: "3 months",
    tools: ["Figma", "After Effects", "Principle"],
    overview: "A complete visual overhaul of a fintech mobile banking application serving over 2M users, focusing on trust, clarity, and seamless transactions.",
    problem: "The existing app suffered from low user engagement and high abandonment rates during onboarding. Users found the interface cluttered and confusing, leading to a 40% drop-off before account creation.",
    process: [
      "Conducted competitive analysis of 12 leading fintech apps",
      "Created user journey maps and identified 8 critical pain points",
      "Developed 3 distinct visual directions with mood boards",
      "Iterated through 40+ wireframes and 15 high-fidelity prototypes",
    ],
    solution: "Introduced a clean, card-based interface with a dark mode option, simplified the onboarding flow from 7 steps to 3, and created a cohesive design system with 200+ reusable components.",
    result: "User engagement increased by 65%, onboarding completion improved by 48%, and the app received a 4.8-star rating on both app stores within the first quarter.",
  },
  {
    id: "mesa-web",
    title: "Mesa",
    subtitle: "SaaS Dashboard & Marketing Site",
    category: "ui",
    categoryLabel: "UI Design",
    image: "https://images.unsplash.com/photo-1648134859211-4a1b57575f4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWJzaXRlJTIwZGVzaWduJTIwZGVza3RvcCUyMG1vY2t1cCUyMG1pbmltYWx8ZW58MXx8fHwxNzc0NTE4MTY3fDA&ixlib=rb-4.1.0&q=80&w=1080",
    year: "2025",
    role: "UI/UX Designer",
    duration: "4 months",
    tools: ["Figma", "Webflow", "Lottie"],
    overview: "Designed the complete web presence for Mesa, a project management SaaS tool, including the marketing website and the internal dashboard interface.",
    problem: "Mesa needed to differentiate itself in a crowded market. Their existing site had poor conversion rates and the dashboard was feature-rich but visually overwhelming.",
    process: [
      "Mapped information architecture for 50+ pages",
      "Created a modular design system in Figma with auto-layout",
      "Designed responsive layouts for all breakpoints",
      "Prototyped micro-interactions for key user flows",
    ],
    solution: "Built a minimalist marketing site with bold typography and strategic whitespace, paired with a dashboard that uses progressive disclosure to manage complexity.",
    result: "Website conversion rate increased 35%. Dashboard task completion time reduced by 22%. Featured in Awwwards Honorable Mentions.",
  },
  {
    id: "botanica",
    title: "Botanica",
    subtitle: "Brand Identity & Packaging System",
    category: "graphic",
    categoryLabel: "Graphic Design",
    image: "https://images.unsplash.com/photo-1669384536597-99ae8c881e65?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYWNrYWdpbmclMjBkZXNpZ24lMjBwcm9kdWN0JTIwYnJhbmRpbmd8ZW58MXx8fHwxNzc0NTE4MTcwfDA&ixlib=rb-4.1.0&q=80&w=1080",
    year: "2024",
    role: "Brand Designer",
    duration: "6 weeks",
    tools: ["Illustrator", "Photoshop", "InDesign"],
    overview: "Created a complete brand identity for Botanica, a premium organic skincare line, including logo, typography, color system, packaging, and brand guidelines.",
    problem: "Botanica needed a visual identity that communicated luxury and sustainability without alienating eco-conscious consumers who distrust overly polished branding.",
    process: [
      "Researched sustainable luxury brand positioning",
      "Explored 60+ logo concepts across 4 visual directions",
      "Developed packaging prototypes with sustainable materials",
      "Created comprehensive brand guidelines document",
    ],
    solution: "Developed an earthy yet refined visual language using hand-drawn botanical illustrations, a muted earth-tone palette, and premium recycled packaging materials.",
    result: "Brand launch exceeded sales targets by 40%. The packaging was featured in Print Magazine's Best Packaging Design 2024.",
  },
  {
    id: "neon-nights",
    title: "Neon Nights",
    subtitle: "Event Poster Series",
    category: "graphic",
    categoryLabel: "Graphic Design",
    image: "https://images.unsplash.com/photo-1762365189058-7be5b07e038b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZCUyMGlkZW50aXR5JTIwZGVzaWduJTIwcG9zdGVyfGVufDF8fHx8MTc3NDUxODE2OHww&ixlib=rb-4.1.0&q=80&w=1080",
    year: "2024",
    role: "Graphic Designer",
    duration: "2 weeks",
    tools: ["Photoshop", "Illustrator"],
    overview: "A series of 12 typographic event posters for a music festival, blending experimental typography with generative patterns.",
    problem: "The festival needed a cohesive yet diverse visual system that could work across digital and print, from billboards to Instagram stories.",
    process: [
      "Studied Swiss poster design and contemporary type experiments",
      "Created custom type treatments using variable fonts",
      "Generated patterns using Processing scripts",
      "Tested print proofs at multiple scales",
    ],
    solution: "Developed a flexible grid system that maintained visual cohesion while allowing each poster to have a unique typographic personality.",
    result: "The series was exhibited at the Type Directors Club and shared across 50+ design blogs. Festival attendance grew 25% year-over-year.",
  },
  {
    id: "abstract-forms",
    title: "Abstract Forms",
    subtitle: "3D Exploration Series",
    category: "3d",
    categoryLabel: "3D Modeling",
    image: "https://images.unsplash.com/photo-1666302707255-13651d539be5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHwzRCUyMHJlbmRlciUyMGFic3RyYWN0JTIwZ2VvbWV0cmljfGVufDF8fHx8MTc3NDQ1MjI5MXww&ixlib=rb-4.1.0&q=80&w=1080",
    year: "2025",
    role: "3D Artist",
    duration: "Ongoing",
    tools: ["Blender", "Cinema 4D", "Octane Render"],
    overview: "A personal exploration series investigating the intersection of organic and geometric forms through procedural 3D modeling and physically-based rendering.",
    problem: "Wanted to push the boundaries of visual storytelling by creating surreal, abstract compositions that challenge conventional perceptions of space and materiality.",
    process: [
      "Studied architectural and sculptural references",
      "Developed custom procedural shaders and materials",
      "Explored generative geometry through scripting",
      "Refined compositions through 100+ render iterations",
    ],
    solution: "Created a library of 24 unique 3D compositions that blend metallic, glass, and organic textures with impossible geometries.",
    result: "Selected for Behance Featured Gallery. Licensed for editorial use by 3 international publications.",
  },
  {
    id: "luxe-ecom",
    title: "Luxe",
    subtitle: "E-Commerce Mini Program",
    category: "ui",
    categoryLabel: "UI Design",
    image: "https://images.unsplash.com/photo-1757301714935-c8127a21abc6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlY29tbWVyY2UlMjBhcHAlMjBpbnRlcmZhY2UlMjBkZXNpZ258ZW58MXx8fHwxNzc0NTE4MTcwfDA&ixlib=rb-4.1.0&q=80&w=1080",
    year: "2024",
    role: "Product Designer",
    duration: "2 months",
    tools: ["Figma", "Sketch", "Principle"],
    overview: "Designed a WeChat Mini Program for a luxury fashion retailer, optimizing the mobile shopping experience for the Chinese market.",
    problem: "The client's existing mobile experience had a 70% cart abandonment rate and poor product discovery, resulting in significant revenue loss.",
    process: [
      "Analyzed user behavior data from 100K+ sessions",
      "Benchmarked against top WeChat Mini Programs",
      "Created user personas based on customer interviews",
      "Designed and tested 3 checkout flow variations",
    ],
    solution: "Implemented an immersive product browsing experience with gesture-based navigation, smart recommendations, and a streamlined 2-tap checkout process.",
    result: "Cart abandonment decreased by 35%. Average order value increased by 28%. The mini program gained 500K users in the first month.",
  },
];

export const timeline = [
  { year: "2025", title: "Senior Visual Designer", company: "Studio Nova", description: "Leading design for enterprise SaaS products and brand systems" },
  { year: "2023", title: "Visual Designer", company: "Pixel & Co.", description: "UI/UX design for mobile apps and web platforms" },
  { year: "2021", title: "Junior Designer", company: "CreativeLab", description: "Graphic design, branding, and print production" },
  { year: "2020", title: "Design Intern", company: "Bright Agency", description: "Assisted on branding projects and social media campaigns" },
  { year: "2020", title: "B.F.A Visual Communication", company: "Art Center College of Design", description: "Focus on typography, interaction design, and 3D visualization" },
];

export const skills = {
  design: ["UI/UX Design", "Brand Identity", "Typography", "Layout & Grid Systems", "Motion Design", "3D Modeling"],
  tools: ["Figma", "Sketch", "Adobe Creative Suite", "Blender", "Cinema 4D", "After Effects", "Webflow", "Principle"],
};
