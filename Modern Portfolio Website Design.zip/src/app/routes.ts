import { createBrowserRouter } from "react-router";
import { HomePage } from "./components/home-page";
import { CaseStudy } from "./components/case-study";

export const router = createBrowserRouter([
  { path: "/", Component: HomePage },
  { path: "/project/:id", Component: CaseStudy },
]);
