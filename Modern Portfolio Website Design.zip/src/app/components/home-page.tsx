import { motion } from "motion/react";
import { useRef } from "react";
import { Link } from "react-router";
import { ArrowUpRight, ArrowDown, Mail, Dribbble, Linkedin, Github } from "lucide-react";
import { projects, timeline, skills } from "../data/projects";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, delay: i * 0.1, ease: [0.25, 0.46, 0.45, 0.94] },
  }),
};

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-4 mb-12 md:mb-16">
      <span className="text-[11px] tracking-[0.2em] uppercase text-black/40">{children}</span>
      <div className="flex-1 h-px bg-black/10" />
    </div>
  );
}

export function HomePage() {
  const workRef = useRef<HTMLElement>(null);

  return (
    <div className="bg-white text-black">
      {/* Hero */}
      <section className="min-h-screen flex flex-col justify-center px-6 md:px-12 max-w-[1400px] mx-auto relative">
        <motion.div
          initial="hidden"
          animate="visible"
          className="pt-24 md:pt-0"
        >
          <motion.p
            variants={fadeUp}
            custom={0}
            className="text-[11px] tracking-[0.25em] uppercase text-black/40 mb-6"
          >
            Visual Designer
          </motion.p>
          <motion.h1
            variants={fadeUp}
            custom={1}
            className="font-[Playfair_Display] text-[clamp(48px,10vw,120px)] leading-[0.95] tracking-tight mb-8"
          >
            Alex<br />Chen
          </motion.h1>
          <motion.p
            variants={fadeUp}
            custom={2}
            className="text-[15px] md:text-[17px] text-black/50 max-w-md leading-relaxed mb-12"
          >
            Crafting meaningful digital experiences through UI design, branding, and 3D visualization.
          </motion.p>
          <motion.div variants={fadeUp} custom={3} className="flex flex-wrap gap-4">
            {["UI / UX", "Branding", "3D"].map((tag) => (
              <span
                key={tag}
                className="px-4 py-1.5 border border-black/10 rounded-full text-[11px] tracking-[0.15em] uppercase text-black/50"
              >
                {tag}
              </span>
            ))}
          </motion.div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 1 }}
          className="absolute bottom-12 left-6 md:left-12"
        >
          <button
            onClick={() => workRef.current?.scrollIntoView({ behavior: "smooth" })}
            className="flex items-center gap-2 text-[11px] tracking-[0.2em] uppercase text-black/30 hover:text-black/60 transition-colors"
          >
            <ArrowDown size={14} />
            Scroll to explore
          </button>
        </motion.div>
      </section>

      {/* Featured Work */}
      <section ref={workRef} id="work" className="px-6 md:px-12 max-w-[1400px] mx-auto py-24 md:py-32">
        <SectionLabel>Selected Work</SectionLabel>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
          {projects.map((project, i) => (
            <motion.div
              key={project.id}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-50px" }}
              variants={fadeUp}
              custom={i % 2 === 0 ? 0 : 0.15}
              className={i === 0 ? "md:col-span-2" : ""}
            >
              <Link to={`/project/${project.id}`} className="group block">
                <div className={`relative overflow-hidden bg-neutral-100 ${i === 0 ? "aspect-[16/8]" : "aspect-[4/3]"}`}>
                  <ImageWithFallback
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-500" />
                </div>
                <div className="mt-5 flex items-start justify-between">
                  <div>
                    <p className="text-[11px] tracking-[0.15em] uppercase text-black/35 mb-1">
                      {project.categoryLabel} &mdash; {project.year}
                    </p>
                    <h3 className="text-[20px] md:text-[24px] font-[Playfair_Display] tracking-tight">
                      {project.title}
                    </h3>
                    <p className="text-[14px] text-black/45 mt-1">{project.subtitle}</p>
                  </div>
                  <ArrowUpRight
                    size={18}
                    className="text-black/20 group-hover:text-black transition-colors duration-300 mt-1 shrink-0"
                  />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="px-6 md:px-12 max-w-[1400px] mx-auto py-16 md:py-24">
        <SectionLabel>Expertise</SectionLabel>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-black/10">
          {[
            { title: "UI Design", items: ["Mobile Apps", "Web Platforms", "Mini Programs", "Design Systems"] },
            { title: "Graphic Design", items: ["Brand Identity", "Posters & Print", "Packaging", "Editorial"] },
            { title: "3D Modeling", items: ["Product Viz", "Abstract Art", "Motion Graphics", "Architectural"] },
          ].map((cat, i) => (
            <motion.div
              key={cat.title}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              custom={i * 0.1}
              className="bg-white p-8 md:p-10"
            >
              <h3 className="font-[Playfair_Display] text-[22px] tracking-tight mb-6">{cat.title}</h3>
              <ul className="space-y-3">
                {cat.items.map((item) => (
                  <li key={item} className="text-[13px] text-black/45 flex items-center gap-3">
                    <span className="w-1 h-1 bg-black/20 rounded-full" />
                    {item}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Timeline */}
      <section className="px-6 md:px-12 max-w-[1400px] mx-auto py-16 md:py-24">
        <SectionLabel>Experience</SectionLabel>
        <div className="max-w-2xl">
          {timeline.map((item, i) => (
            <motion.div
              key={i}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              custom={i * 0.08}
              className="flex gap-6 md:gap-10 pb-10 last:pb-0 relative"
            >
              <div className="flex flex-col items-center">
                <div className="w-2.5 h-2.5 rounded-full bg-black/80 shrink-0 mt-1" />
                {i < timeline.length - 1 && <div className="w-px flex-1 bg-black/10 mt-2" />}
              </div>
              <div className="pb-2">
                <p className="text-[11px] tracking-[0.15em] uppercase text-black/35 mb-1">{item.year}</p>
                <h4 className="text-[16px] tracking-tight">{item.title}</h4>
                <p className="text-[13px] text-black/50 mt-0.5">{item.company}</p>
                <p className="text-[13px] text-black/35 mt-2 leading-relaxed">{item.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* About */}
      <section id="about" className="px-6 md:px-12 max-w-[1400px] mx-auto py-16 md:py-24">
        <SectionLabel>About</SectionLabel>
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 md:gap-16">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            className="md:col-span-4"
          >
            <div className="aspect-[3/4] bg-neutral-100 overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1758613654360-45f1ff78c0cf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwcG9ydHJhaXQlMjBwcm9mZXNzaW9uYWwlMjBoZWFkc2hvdHxlbnwxfHx8fDE3NzQ1MTgxNzB8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Alex Chen portrait"
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            custom={0.15}
            className="md:col-span-8"
          >
            <p className="text-[17px] md:text-[20px] leading-[1.7] text-black/70 mb-10 max-w-xl">
              I'm a visual designer with 5+ years of experience creating digital products, brand identities, and 3D visuals. I believe in design that is both beautiful and purposeful — every pixel should earn its place.
            </p>
            <p className="text-[15px] leading-[1.7] text-black/45 mb-12 max-w-xl">
              Currently based in San Francisco, I specialize in transforming complex problems into elegant, intuitive experiences. My work spans startups to Fortune 500 companies, always with a focus on craft and impact.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-10">
              <div>
                <h4 className="text-[11px] tracking-[0.2em] uppercase text-black/35 mb-4">Skills</h4>
                <ul className="space-y-2">
                  {skills.design.map((s) => (
                    <li key={s} className="text-[13px] text-black/55">{s}</li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="text-[11px] tracking-[0.2em] uppercase text-black/35 mb-4">Tools</h4>
                <ul className="space-y-2">
                  {skills.tools.map((t) => (
                    <li key={t} className="text-[13px] text-black/55">{t}</li>
                  ))}
                </ul>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="px-6 md:px-12 max-w-[1400px] mx-auto py-24 md:py-32">
        <SectionLabel>Contact</SectionLabel>
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUp}
          className="text-center max-w-xl mx-auto"
        >
          <h2 className="font-[Playfair_Display] text-[clamp(32px,5vw,56px)] tracking-tight mb-6">
            Let's work together
          </h2>
          <p className="text-[15px] text-black/45 mb-10 leading-relaxed">
            I'm always open to discussing new projects, creative ideas, or opportunities to be part of your vision.
          </p>
          <a
            href="mailto:hello@alexchen.design"
            className="inline-flex items-center gap-3 px-8 py-4 bg-black text-white text-[13px] tracking-[0.1em] uppercase hover:bg-black/85 transition-colors duration-300"
          >
            <Mail size={16} />
            hello@alexchen.design
          </a>
          <div className="flex items-center justify-center gap-6 mt-10">
            {[
              { icon: Dribbble, label: "Dribbble" },
              { icon: Linkedin, label: "LinkedIn" },
              { icon: Github, label: "GitHub" },
            ].map(({ icon: Icon, label }) => (
              <a
                key={label}
                href="#"
                className="p-2 text-black/25 hover:text-black transition-colors duration-300"
                aria-label={label}
              >
                <Icon size={20} />
              </a>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="border-t border-black/5 px-6 md:px-12 max-w-[1400px] mx-auto py-8 flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="text-[11px] text-black/30 tracking-[0.1em] uppercase">
          &copy; 2026 Alex Chen. All rights reserved.
        </p>
        <p className="text-[11px] text-black/30">
          Designed & built with care
        </p>
      </footer>
    </div>
  );
}
