import { useParams, Link, Navigate } from "react-router";
import { motion } from "motion/react";
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import { projects } from "../data/projects";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.1, ease: [0.25, 0.46, 0.45, 0.94] },
  }),
};

function Block({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-40px" }}
      variants={fadeUp}
      className="grid grid-cols-1 md:grid-cols-12 gap-6 md:gap-16 py-12 md:py-16 border-t border-black/5"
    >
      <div className="md:col-span-3">
        <span className="text-[11px] tracking-[0.2em] uppercase text-black/35">{label}</span>
      </div>
      <div className="md:col-span-9">{children}</div>
    </motion.div>
  );
}

export function CaseStudy() {
  const { id } = useParams();
  const project = projects.find((p) => p.id === id);
  const currentIndex = projects.findIndex((p) => p.id === id);
  const nextProject = projects[(currentIndex + 1) % projects.length];

  if (!project) return <Navigate to="/" replace />;

  return (
    <div className="bg-white text-black">
      {/* Back */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-black/5">
        <div className="max-w-[1400px] mx-auto px-6 md:px-12 h-16 md:h-20 flex items-center">
          <Link
            to="/"
            className="flex items-center gap-2 text-[12px] tracking-[0.1em] uppercase text-black/50 hover:text-black transition-colors"
          >
            <ArrowLeft size={16} />
            Back
          </Link>
        </div>
      </div>

      {/* Hero */}
      <div className="pt-20 md:pt-24">
        <div className="max-w-[1400px] mx-auto px-6 md:px-12 py-16 md:py-24">
          <motion.div initial="hidden" animate="visible">
            <motion.p variants={fadeUp} custom={0} className="text-[11px] tracking-[0.2em] uppercase text-black/35 mb-4">
              {project.categoryLabel}
            </motion.p>
            <motion.h1 variants={fadeUp} custom={1} className="font-[Playfair_Display] text-[clamp(36px,7vw,80px)] leading-[1] tracking-tight mb-4">
              {project.title}
            </motion.h1>
            <motion.p variants={fadeUp} custom={2} className="text-[17px] text-black/45 mb-10">
              {project.subtitle}
            </motion.p>
            <motion.div variants={fadeUp} custom={3} className="flex flex-wrap gap-x-10 gap-y-3">
              {[
                { label: "Role", value: project.role },
                { label: "Duration", value: project.duration },
                { label: "Year", value: project.year },
              ].map(({ label, value }) => (
                <div key={label}>
                  <span className="text-[11px] tracking-[0.15em] uppercase text-black/30 block mb-0.5">{label}</span>
                  <span className="text-[14px] text-black/70">{value}</span>
                </div>
              ))}
              <div>
                <span className="text-[11px] tracking-[0.15em] uppercase text-black/30 block mb-0.5">Tools</span>
                <span className="text-[14px] text-black/70">{project.tools.join(", ")}</span>
              </div>
            </motion.div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="max-w-[1400px] mx-auto px-6 md:px-12"
        >
          <div className="aspect-[16/9] bg-neutral-100 overflow-hidden">
            <ImageWithFallback
              src={project.image}
              alt={project.title}
              className="w-full h-full object-cover"
            />
          </div>
        </motion.div>
      </div>

      {/* Content */}
      <div className="max-w-[1400px] mx-auto px-6 md:px-12 py-12 md:py-20">
        <Block label="Overview">
          <p className="text-[16px] md:text-[18px] leading-[1.75] text-black/65 max-w-2xl">{project.overview}</p>
        </Block>

        <Block label="Problem">
          <p className="text-[15px] leading-[1.75] text-black/55 max-w-2xl">{project.problem}</p>
        </Block>

        <Block label="Process">
          <ol className="space-y-4 max-w-2xl">
            {project.process.map((step, i) => (
              <li key={i} className="flex gap-4 text-[15px] leading-[1.7] text-black/55">
                <span className="text-[12px] text-black/25 mt-0.5 shrink-0">{String(i + 1).padStart(2, "0")}</span>
                {step}
              </li>
            ))}
          </ol>
        </Block>

        <Block label="Solution">
          <p className="text-[15px] leading-[1.75] text-black/55 max-w-2xl">{project.solution}</p>
        </Block>

        {/* Visual showcase mockup */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUp}
          className="py-12 md:py-16"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="aspect-[4/3] bg-neutral-50 overflow-hidden">
              <ImageWithFallback
                src={project.image}
                alt={`${project.title} detail 1`}
                className="w-full h-full object-cover opacity-90"
              />
            </div>
            <div className="aspect-[4/3] bg-neutral-50 overflow-hidden">
              <ImageWithFallback
                src={project.image}
                alt={`${project.title} detail 2`}
                className="w-full h-full object-cover opacity-90 scale-110"
              />
            </div>
          </div>
        </motion.div>

        <Block label="Result">
          <p className="text-[16px] md:text-[18px] leading-[1.75] text-black/65 max-w-2xl">{project.result}</p>
        </Block>
      </div>

      {/* Next project */}
      <div className="border-t border-black/5 max-w-[1400px] mx-auto px-6 md:px-12 py-20 md:py-28">
        <p className="text-[11px] tracking-[0.2em] uppercase text-black/30 mb-6">Next Project</p>
        <Link to={`/project/${nextProject.id}`} className="group flex items-end justify-between">
          <h2 className="font-[Playfair_Display] text-[clamp(28px,5vw,48px)] tracking-tight group-hover:text-black/70 transition-colors">
            {nextProject.title}
          </h2>
          <ArrowUpRight size={28} className="text-black/20 group-hover:text-black transition-colors mb-2" />
        </Link>
      </div>
    </div>
  );
}
